<?php
/**
 * Plugin Name: sanitize titles
 * Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
 * Description: sanitize the titles of all pages
 * Version: 1
 * Author: leta
 *
 * 1. get 0 parent titles
 * 2. sanitize titles
 * 3. print titles
 * 4. get titles with parents
 * 5. sanitize titles
 * 6. print titles in hierarchy
 * 7. repeat until all childrens are ded. or not there.
 */


$pages = get_pages();

foreach( $pages as $page ) {
	echo $page->post_title . ' ';
	echo sanitize_title_with_dashes( $page->post_title ) . '<br />';
}

?>